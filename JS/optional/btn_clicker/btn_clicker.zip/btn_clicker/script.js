// function logOut(out){
//     document.getElementById("login").innerText = "LogOut";
// }

function logOut(login){
    var login = document.getElementById("login");
    if (login.innerText=="logout"){
        login.innerText="login";
    } else{
        login.innerText="logout";
    }
}

function removeButton(elem){
    var elem = document.getElementById("add");
    elem.remove();
}

removeButton(elem);