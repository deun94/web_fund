//factorials! fun


//for loop
var product= 1;

for(i=1; i<=12; i++){
    product *=i;
}
console.log(product);

//while loop

var product=1;
var i=1;

//while loop you gta define two var so for is better here
while(i<=12){
    product*=i;
    i++;
}
console.log(product);